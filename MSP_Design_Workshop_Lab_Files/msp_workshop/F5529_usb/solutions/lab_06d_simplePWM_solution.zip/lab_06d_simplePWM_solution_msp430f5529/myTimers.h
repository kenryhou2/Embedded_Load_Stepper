/*
 * myTimers.h
 *
 */

#ifndef MYTIMERS_H_
#define MYTIMERS_H_

// Prototypes
void initTimers( uint16_t, uint16_t );


#endif /* MYTIMERS_H_ */

