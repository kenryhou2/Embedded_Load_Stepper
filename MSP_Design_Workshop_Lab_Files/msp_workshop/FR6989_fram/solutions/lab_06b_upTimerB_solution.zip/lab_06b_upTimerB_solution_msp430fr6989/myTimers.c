// ----------------------------------------------------------------------------
// myTimers.c  (for lab_06b_upTimerB project) ('FR6989 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>
#include "myTimers.h"

//***** Defines ***************************************************************


//***** Global Variables ******************************************************


//*****************************************************************************
// Initialize Timer
//*****************************************************************************
void initTimers(void)
{
    // 1. Setup Timer (TAR, TACTL)
    //    TimerB0 in Up mode using ACLK
    //    Toggle LED1 (Red) on/off every second using CCR0IFG
    //    Toggle LED2 (Green) on/off every second using TB0IFG
    Timer_B_initUpModeParam initUpParam = { 0 };
        initUpParam.clockSource = TIMER_B_CLOCKSOURCE_ACLK;                       // Use ACLK (slower clock)
        initUpParam.clockSourceDivider = TIMER_B_CLOCKSOURCE_DIVIDER_1;           // Input clock = ACLK / 1 = 32KHz
        initUpParam.timerPeriod = 0xFFFF / 2;                                     // Period (0xFFFF/2):  8000 / 32Khz = 1 second
        initUpParam.timerInterruptEnable_TBIE = TIMER_B_TBIE_INTERRUPT_ENABLE;    // Enable TBR -> 0 interrupt
        initUpParam.captureCompareInterruptEnable_CCR0_CCIE =
                TIMER_B_CCIE_CCR0_INTERRUPT_ENABLE;                               // Enable CCR0 compare interrupt
        initUpParam.timerClear = TIMER_B_DO_CLEAR;                                // Clear TBR & clock divider
        initUpParam.startTimer = false;                                           // Don't start the timer, yet
    Timer_B_initUpMode( TIMER_B0_BASE, &initUpParam );                            // Set up Timer B0

    // 2. Setup Capture & Compare features
       // This example does not use these features
       // CCR0 is setup by the Timer_B_initUpMode function

    // 3. Clear/enable flags and start timer
    Timer_B_clearTimerInterrupt( TIMER_B0_BASE );                                 // Clear TB0IFG
    Timer_B_clearCaptureCompareInterrupt( TIMER_B0_BASE,
        TIMER_B_CAPTURECOMPARE_REGISTER_0                                         // Clear CCR0IFG
    );

    //These two enables are already done by the configureUpMode function
    //Timer_B_enableInterrupt( TIMER_B0_BASE );                                   // Enable TB0IFG (TBR rollover to 0)
    //Timer_B_enableCaptureCompareInterrupt(TIMER_B0_BASE,
    //    TIMER_B_CAPTURECOMPARE_REGISTER_0                                       // Enable CCR0IFG
    //);

    Timer_B_startCounter(
        TIMER_B0_BASE,
        TIMER_B_UP_MODE
    );
}

//*****************************************************************************
// Interrupt Service Routines
//*****************************************************************************
#pragma vector=TIMER0_B0_VECTOR
__interrupt void ccr0_ISR (void)
{
    // 4. Timer ISR and vector

    // Toggle LED1 on/off
    GPIO_toggleOutputOnPin( GPIO_PORT_P1, GPIO_PIN0 );
}

#pragma vector=TIMER0_B1_VECTOR
__interrupt void timer0_ISR (void)
{
    // 4. Timer ISR and vector

    switch( __even_in_range( TB0IV, TB0IV_TBIFG )) {
        case TB0IV_NONE:   break;                               // (0x00) No Interrupt pending 
        case TB0IV_TBCCR1:                                      // (0x02) CCR1 IFG
             __no_operation();
             break;
       case TB0IV_TBCCR2:                                       // (0x04) CCR2 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR3:                                       // (0x06) CCR3 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR4:                                       // (0x08) CCR4 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR5:                                       // (0x0A) CCR5 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR6:                                       // (0x0C) CCR6 IFG
            __no_operation();
            break;
       case TB0IV_TBIFG:                                        // (0x0E) TB0IFG - TBR overflow
            // Toggle LED2 (Green) LED on/off
            GPIO_toggleOutputOnPin( GPIO_PORT_P9, GPIO_PIN7 );
            break;
       default:   _never_executed();
    }
}

