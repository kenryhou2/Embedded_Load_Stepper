lab_06c_timerHalP1

This lab is a variation on the lab_06c_timerHal project. As with the "P1"
solution for the lab_06c_timerDirectDriveP1Led, this solution redirects
the timers output to pin P1.0. Because of this, you don't need a jumper 
to see the output of the timer on the MSP-EXP430FR5994 LaunchPad.

The main differences in the lab are encapsulated in "hal.h"; minor changes
can be seen in the timer setup.

<file insert>hal.h
<file insert>myTimers.c
