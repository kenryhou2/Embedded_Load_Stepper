// ----------------------------------------------------------------------------
// myTimers.c  (for lab_06c_timerDirectDriveLed project) ('FR5994 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>
#include "myGpio.h"
#include "myTimers.h"

//***** Defines ***************************************************************


//***** Global Variables ******************************************************
// Timer_A configuration parameters for Up mode
Timer_A_initUpModeParam gInitUpParam = {
    TIMER_A_CLOCKSOURCE_ACLK,                                                   // Use ACLK (slower clock)
    TIMER_A_CLOCKSOURCE_DIVIDER_1,                                              // Input clock = ACLK / 1 = 32KHz
    0xFFFF / 2,                                                                 // Period (0xFFFF/2):  8000 / 32Khz = 1 second
    TIMER_A_TAIE_INTERRUPT_ENABLE,                                              // Enable TAR -> 0 interrupt
    TIMER_A_CCIE_CCR0_INTERRUPT_DISABLE,                                        // Enable CCR0 compare interrupt
    TIMER_A_DO_CLEAR,                                                           // Clear TAR & clock divider
    false                                                                       // Don't start timer automatically
};

// Timer_A configuration for CCR1 compare parameters
// Using TA0.CCR1 lets us output the timer directly to P1.0
Timer_A_initCompareModeParam gInitCcr1Param = {
    TIMER_A_CAPTURECOMPARE_REGISTER_1,                                          // Use CCR2 for compare
    TIMER_A_CAPTURECOMPARE_INTERRUPT_DISABLE,                                   // Since directly driving LED, interrup not req'd
    TIMER_A_OUTPUTMODE_TOGGLE_RESET,                                            // Toggle provides a 1 sec period based on CCR0 and CCR2 values
    0x4000                                                                      // Compare value: 4000 = 1/2 second
};


//*****************************************************************************
// Initialize Timer
//*****************************************************************************
void initTimers(void)
{
    //*************************************************************************
    // 1. Setup Timer (TAR, TACTL)
    //    TimerA0 in Up mode using ACLK
    //    Toggle LED1 on/off every second directly from the timers CCR1 output pin (jumper needed)
    //    Toggle LED2 on/off every second using TA0IFG
    //    Note: gInitUpParam was created as a global variable. This could have been done as a local variable, too.
    //          As an example, we show configuring the Period dynamically, but this value could have been set globally, as well.
    //*************************************************************************
    Timer_A_initUpMode( TIMER_A0_BASE, &gInitUpParam );                         // Set up Timer A1

    //*************************************************************************
    // 2. Setup Capture & Compare features
    //*************************************************************************
    Timer_A_initCompareMode( TIMER_A0_BASE, &gInitCcr1Param );

    //*************************************************************************
    // 3. Clear/enable flags and start timer
    //*************************************************************************
    Timer_A_clearTimerInterrupt( TIMER_A0_BASE );                                 // Clear TA0IFG

    Timer_A_startCounter(
        TIMER_A0_BASE,
        TIMER_A_UP_MODE
    );
}

//*****************************************************************************
// Interrupt Service Routines
//*****************************************************************************
//#pragma vector = TIMER0_A0_VECTOR
//__interrupt void ccr0_ISR ( void )
//{
//    //**************************************************************************
//    // 4. Timer ISR and vector
//    //**************************************************************************
//    // Toggle LED1 on/off
//    GPIO_toggleOutputOnPin( LED1_PORT, LED1_PIN );
//}

#pragma vector = TIMER0_A1_VECTOR
__interrupt void timer0_ISR ( void )
{
    //**************************************************************************
    // 4. Timer ISR and vector
    //**************************************************************************
    switch( __even_in_range( TA0IV, TA0IV_TAIFG )) {
     case TA0IV_NONE: break;                 // (0x00) None
     case TA0IV_TACCR1:                      // (0x02) CCR1 IFG
          _no_operation();
           break;
     case TA0IV_TACCR2:                      // (0x04) CCR2 IFG
          _no_operation();
           break;
     case TA0IV_3: break;                    // (0x06) Reserved
     case TA0IV_4: break;                    // (0x08) Reserved
     case TA0IV_5: break;                    // (0x0A) Reserved
     case TA0IV_6: break;                    // (0x0C) Reserved
     case TA0IV_TAIFG:                       // (0x0E) TA0IFG - TAR overflow
          // Toggle LED2 on/off
          GPIO_toggleOutputOnPin( LED2_PORT, LED2_PIN );
          break;
     default: _never_executed();
    }
}

