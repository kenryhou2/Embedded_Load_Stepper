// ----------------------------------------------------------------------------
// myGpio.c  (for lab_03b_button_solution project)  ('FR5994 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>                                                          // DriverLib include file
#include "myGpio.h"


//*****************************************************************************
// Initialize GPIO
//*****************************************************************************
void initGPIO(void) {

    //**************************************************************************
    // Configure LaunchPad LEDs
    //**************************************************************************
    // Set red and green LEDs to output direction, then turn them off
    GPIO_setAsOutputPin(
            GPIO_PORT_P1,
            GPIO_PIN0 +                                                         // Red LED (LED1)
            GPIO_PIN1                                                           // Green LED (LED2)
    );

    GPIO_setOutputLowOnPin(
            GPIO_PORT_P1,
            GPIO_PIN0 +
            GPIO_PIN1
    );

    //**************************************************************************
    // Unlock pins (required for most FRAM devices)
    // Unless waking from LPMx.5, this should be done before clearing and enabling GPIO port interrupts
    //**************************************************************************
    PMM_unlockLPM5();

    //**************************************************************************
    // Configure LaunchPad Buttons
    //**************************************************************************
    // Set the GPIO pins connected to the pushbuttons as inputs with pull-up resistors
    // GPIO interrupt configuration will be discussed in "Interrupts" chapter
    GPIO_setAsInputPinWithPullUpResistor(
            GPIO_PORT_P5,
            GPIO_PIN6 +                                                         // Pushbutton 1 (S1)
            GPIO_PIN5                                                           // Pushbutton 2 (S2)
    );

    //**************************************************************************
    // Configure Timer Output pin(s)
    //**************************************************************************
    // Discussed in Timer chapter

    //**************************************************************************
    // Configure external crystal pins
    //**************************************************************************
    // Set LFXT (low freq crystal pins) to crystal input (rather than GPIO)
    // Since HFXT is not used, we don't need to set these pins. But for the 
    // record, they are:
    //              GPIO_PIN6                                                   // HFXTIN on PJ.6
    //              GPIO_PIN7                                                   // HFXOUT on PJ.7
    GPIO_setAsPeripheralModuleFunctionInputPin(
                    GPIO_PORT_PJ,
                    GPIO_PIN4 +                                                 // LFXIN  on PJ.4
                    GPIO_PIN5 ,                                                 // LFXOUT on PJ.5
                    GPIO_PRIMARY_MODULE_FUNCTION
    );

    //**************************************************************************
    // Output MSP clock signals to external pins
    // - This allows verifying the clocks with a logic analyzer
    //**************************************************************************
    //Output the MCLK and SMCLK signals to their respective pins to allow watching them with logic analyzer
    GPIO_setAsPeripheralModuleFunctionOutputPin(
                    GPIO_PORT_P5,
                    GPIO_PIN7,                                                // MCLK on P5.7
                    GPIO_TERNARY_MODULE_FUNCTION
    );

    GPIO_setAsPeripheralModuleFunctionOutputPin(
                    GPIO_PORT_P3,
                    GPIO_PIN4,                                                // SMCLK on P3.4
                    GPIO_SECONDARY_MODULE_FUNCTION
    );
}

//*****************************************************************************
// Interrupt Service Routines
//*****************************************************************************
// Discussed in Interrupts chapter
