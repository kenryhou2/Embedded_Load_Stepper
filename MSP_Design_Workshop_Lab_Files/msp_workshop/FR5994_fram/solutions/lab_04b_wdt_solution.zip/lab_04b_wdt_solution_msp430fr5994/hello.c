// ----------------------------------------------------------------------------
// hello.c  (for lab_04b_wdt project)
// ----------------------------------------------------------------------------
#include <stdio.h>
#include <driverlib.h>

uint16_t count = 0;

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;                                                   // Stop watchdog timer

    // Initialize the WDT as a watchdog
    WDT_A_initWatchdogTimer( WDT_A_BASE,
                             WDT_A_CLOCKSOURCE_ACLK,                            // Which clock should WDT use?
                             //WDT_A_CLOCKDIVIDER_64  );                        // WDT clock input divisor
                               WDT_A_CLOCKDIVIDER_512 );                        //   Here are 3 (of 8) divisor choices
                             //WDT_A_CLOCKDIVIDER_32K );

    // Start the watchdog
    WDT_A_start( WDT_A_BASE );

    while (1) {
        //WDT_A_resetTimer( WDT_A_BASE );

        count++;
        printf( "I called this %d times\n", count );
    }
}
