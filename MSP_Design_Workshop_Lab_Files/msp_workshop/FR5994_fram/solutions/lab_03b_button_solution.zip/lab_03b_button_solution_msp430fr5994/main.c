// ----------------------------------------------------------------------------
// main.c  (for lab_03b_button project) ('FR5994 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>                                                          // DriverLib include file
#include "myGpio.h"


//***** Prototypes ************************************************************


//***** Defines ***************************************************************


//***** Global Variables ******************************************************
volatile unsigned short usiButton1 = 0;

//*****************************************************************************
// Main
//*****************************************************************************
void main (void)
{
    // Stop watchdog timer
    WDT_A_hold( WDT_A_BASE );

    // Initialize GPIO
    initGPIO();

    while(1) {
        // Read Pushbutton, then turn LED on if the Pushbutton is pushed down
        usiButton1 = GPIO_getInputPinValue ( BUTTON1_PORT, BUTTON1_PIN );

        if ( usiButton1 == GPIO_INPUT_PIN_LOW ) {
            GPIO_setOutputHighOnPin( LED1_PORT, LED1_PIN );                     // If button is down, turn on LED
        }
        else {
            GPIO_setOutputLowOnPin( LED1_PORT, LED1_PIN );                      // If button is up, turn off LED
        }
    }
}

