// ----------------------------------------------------------------------------
// myTimers.c  (for lab_06b_upTimerB project) ('FR5994 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>
#include "myGpio.h"
#include "myTimers.h"

//***** Defines ***************************************************************


//***** Global Variables ******************************************************
// Timer_B configuration parameters for Up mode
Timer_B_initUpModeParam gInitUpParamB = {
    TIMER_B_CLOCKSOURCE_ACLK,                                                  // Use ACLK (slower clock)
    TIMER_B_CLOCKSOURCE_DIVIDER_1,                                             // Input clock = ACLK / 1 = 32KHz
    0,                                                                         // Period (set to "0", we'll set actual value later)
    TIMER_B_TBIE_INTERRUPT_ENABLE,                                             // Enable TAR -> 0 interrupt
    TIMER_B_CCIE_CCR0_INTERRUPT_ENABLE,                                        // Enable CCR0 compare interrupt
    TIMER_B_DO_CLEAR,                                                          // Clear TAR & clock divider
    false                                                                      // Don't start timer automatically
};


//*****************************************************************************
// Initialize Timer
//*****************************************************************************
void initTimers(void)
{
    //*************************************************************************
    // 1. Setup Timer (TBR, TBCTL)
    //    TimerB0 in Up mode using ACLK
    //    Toggle LED1 (Red) on/off every second using CCR0IFG
    //    Toggle LED2 (Green) on/off every second using TB0IFG
    //    Note: gInitUpParam was created as a global variable. This could have been done as a local variable, too.
	//          As an example, we show configuring the Period dynamically, but this value could have been set globally, as well.
    //*************************************************************************
	gInitUpParamB.timerPeriod = 0xFFFF / 2;                                     // Period (0xFFFF/2):  8000 / 32Khz = 1 second
    Timer_B_initUpMode( TIMER_B0_BASE, &gInitUpParamB );                        // Set up Timer B0

    //*************************************************************************
    // 2. Setup Capture & Compare features
    //*************************************************************************
       // This example does not use these features
       // CCR0 is setup by the Timer_B_initUpMode function

    //*************************************************************************
    // 3. Clear/enable flags and start timer
    //*************************************************************************
    Timer_B_clearTimerInterrupt( TIMER_B0_BASE );                                 // Clear TB0IFG
    Timer_B_clearCaptureCompareInterrupt( TIMER_B0_BASE,
        TIMER_B_CAPTURECOMPARE_REGISTER_0                                         // Clear CCR0IFG
    );

    //These two enables are already done by the configureUpMode function
    //Timer_B_enableInterrupt( TIMER_B0_BASE );                                   // Enable TB0IFG (TBR rollover to 0)
    //Timer_B_enableCaptureCompareInterrupt(TIMER_B0_BASE,
    //    TIMER_B_CAPTURECOMPARE_REGISTER_0                                       // Enable CCR0IFG
    //);

    Timer_B_startCounter(
        TIMER_B0_BASE,
        TIMER_B_UP_MODE
    );
}

//*****************************************************************************
// Interrupt Service Routines
//*****************************************************************************
#pragma vector = TIMER0_B0_VECTOR
__interrupt void ccr0_ISR ( void )
{
    //**************************************************************************
    // 4. Timer ISR and vector
    //**************************************************************************
    // Toggle LED1 on/off
    GPIO_toggleOutputOnPin( LED1_PORT, LED1_PIN );
}

#pragma vector = TIMER0_B1_VECTOR
__interrupt void timer0_ISR (void)
{
    //**************************************************************************
    // 4. Timer ISR and vector
    //**************************************************************************
    switch( __even_in_range( TB0IV, TB0IV_TBIFG )) {
        case TB0IV_NONE:   break;                               // (0x00) No Interrupt pending 
        case TB0IV_TBCCR1:                                      // (0x02) CCR1 IFG
             __no_operation();
             break;
       case TB0IV_TBCCR2:                                       // (0x04) CCR2 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR3:                                       // (0x06) CCR3 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR4:                                       // (0x08) CCR4 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR5:                                       // (0x0A) CCR5 IFG
            __no_operation();
            break;
       case TB0IV_TBCCR6:                                       // (0x0C) CCR6 IFG
            __no_operation();
            break;
       case TB0IV_TBIFG:                                        // (0x0E) TB0IFG - TBR overflow
            // Toggle LED2 (Green) LED on/off
            GPIO_toggleOutputOnPin( LED2_PORT, LED2_PIN );
            break;
       default:   _never_executed();
    }
}

