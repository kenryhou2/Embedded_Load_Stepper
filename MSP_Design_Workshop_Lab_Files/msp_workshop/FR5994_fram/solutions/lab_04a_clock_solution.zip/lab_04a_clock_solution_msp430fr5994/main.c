// ----------------------------------------------------------------------------
// main.c  (for lab_04a_clock project) ('FR5994 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>
#include "myGpio.h"
#include "myClocks.h"


//***** Prototypes ************************************************************


//***** Defines ***************************************************************
#define ONE_SECOND  8000000
#define HALF_SECOND 4000000


//***** Global Variables ******************************************************


//*****************************************************************************
// Main
//*****************************************************************************
void main (void)
{
    // Stop watchdog timer
    WDT_A_hold( WDT_A_BASE );

    // Initialize GPIO
    initGPIO();

    // Initialize clocks
    initClocks();

    while(1) {
        // Turn on LED
        GPIO_setOutputHighOnPin( LED1_PORT, LED1_PIN );

        // Wait about a second
        __delay_cycles( ONE_SECOND );

        // Turn off LED
        GPIO_setOutputLowOnPin( LED1_PORT, LED1_PIN );

        // Wait another second
        __delay_cycles( HALF_SECOND );
    }
}
