// ----------------------------------------------------------------------------
// main.c  (for lab_03b_button project) ('FR5969 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib.h>


//***** Prototypes ************************************************************


//***** Defines ***************************************************************


//***** Global Variables ******************************************************
volatile unsigned short usiButton1 = 0;

//*****************************************************************************
// Main
//*****************************************************************************
void main (void)
{
    // Stop watchdog timer
    WDT_A_hold( WDT_A_BASE );

    // Set pin P1.0 to output direction and turn LED off
    GPIO_setAsOutputPin( GPIO_PORT_P1, GPIO_PIN0 );                             // Green LED (LED2)
    GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );

    // Set P1.1 as a digital input pin
    GPIO_setAsInputPinWithPullUpResistor( GPIO_PORT_P1, GPIO_PIN1 );            // Switch 2 (S2)

    // Unlock pins (required for most FRAM devices)
    // Unless waking from LPMx.5, this should be done before clearing and enabling GPIO port interrupts
    PMM_unlockLPM5();

    while(1) {
        // Read pin P1.1 which is connected to push button 2
        usiButton1 = GPIO_getInputPinValue ( GPIO_PORT_P1, GPIO_PIN1 );

        if ( usiButton1 == GPIO_INPUT_PIN_LOW ) {          
            GPIO_setOutputHighOnPin( GPIO_PORT_P1, GPIO_PIN0 );                 // If button is down, turn on LED
        }
        else {       
            GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );                  // If button is up, turn off LED
        }
    }
}

